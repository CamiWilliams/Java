package hw4;
/**
 * Possible status of a maze cell.
 */
  public enum Status {UNEXPLORED, EXPLORING, FAILED, SUCCEEDED, GOAL};
